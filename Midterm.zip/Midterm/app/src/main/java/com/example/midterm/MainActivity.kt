package com.example.midterm

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        towerOfHanoi(3,"A", "B", "C")
    }
}


fun towerOfHanoi(n: Int, a: String, b: String, c:String): Unit {
    // if(n==0){
    //     println("We are done")
    //       return
    // }
    if(n==1){
        println("From $a to $c")
        return
    }
    towerOfHanoi(n-1,a,b,c)
    println("From $a to $c")
    towerOfHanoi(n-1, b,c,a)
}
